
This code generates metabolic models for the analysis contained in the
paper: "In silico modelling of liver metabolism in a human disease
reveals a key enzyme for histidine and histamine homeostasis", Cell
Reports, 2016. The models are stored in Matlab format for further
analysis with code attached to the same paper.

The analysis uses a modified version of cobrapy that can be found
here: https://github.com/franapoli/cobrapy

The models produced are based on data contained in the folder
data/in. Those data were distributed by Gille et al.: "HepatoNet1: a
comprehensive metabolic reconstruction of the human hepatocyte for the
analysis of liver physiology", Mol. Sys. Biol., 2010.

The file "functions.py" contains parts of the script divided into
blocks for convenience (not following the functional programming
paradigm by any means).

The different blocks are run in the correct order by the file
"exportMat.py". The script loads the Hepatonet1 model, extends it with
additional reactions and finally creates 442 models, each containing a
different set of objective functions. By default the models are stored
in the directory "data/MetabolicObjectives", each in a different mat
file named "Hepa1MetabolicObjSlim_XXX.mat", with XXX being a number
between 1 and 442. Each mat file contains a variable "Matlab" with the
model data as defined by the cobrapy package.

Contact: Francesco Napolitano, franapoli@gmail.com
