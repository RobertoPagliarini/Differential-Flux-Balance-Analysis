import scipy
from scipy.io import loadmat
from cobra.core.ArrayBasedModel import SMatrix_lil

execfile("functions.py")

outdir = os.path.join("data", "MetabolicObjectives")
outprefix = "Hepa1MetabolicObjSlim_"

model, lines, constrSignsAndNames = buildModel()
addReverseRxns(model)
add50Rxns(model)

W = importW()
K = importGibbs()
c=W
c.extend([x[0]*x[1] for x in zip(K,W)])
c.extend([1]*(len(model.reactions)-len(c)))
nmets = [i for i,r in enumerate(model.reactions) if len(r._metabolites)<2]
for i in nmets: c[i]=0
for ci,cv in enumerate(c): model.reactions[ci].objective_coefficient = cv

if not os.path.exists(outdir):
    os.makedirs(outdir)

import scipy
enzymes=dict()
enzymes["enzymes"]=importEnzymes()
scipy.io.savemat(os.path.join(outdir, "enzymes.mat"), enzymes)

for i, line in enumerate(lines):
    print "** " + str(i) + ": " + str(line)

    inms = [m[1:] for m in constrSignsAndNames[i]]
    modeli = copy.deepcopy(model)
    constrIds = names2ids(modeli, constrSignsAndNames)
    reactions = buildReactionSet(modeli, lines, i, constrIds, constrSignsAndNames)
    rmDups(reactions)
    modeli.add_reactions(reactions)
        
    c2=copy.deepcopy(c)
    c2.extend([0]*(len(modeli.reactions)-len(c2)))
    for ci,cv in enumerate(c2): modeli.reactions[ci].objective_coefficient = cv
    fname = os.path.join(outdir, outprefix + str(i+1) + ".mat")
    cobra.io.save_matlab_model(modeli, fname, "Model")
 
