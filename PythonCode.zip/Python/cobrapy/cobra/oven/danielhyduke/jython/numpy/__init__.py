from cern.colt.matrix.impl import DenseDoubleMatrix2D as ndarray
from cern.colt.matrix.impl import SparseDoubleMatrix2D as sdarray
from core import *
#import core
#from core import *
