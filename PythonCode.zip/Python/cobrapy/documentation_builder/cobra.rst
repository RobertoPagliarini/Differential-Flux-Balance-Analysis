cobra package
=============

Subpackages
-----------

.. toctree::

    cobra.core
    cobra.flux_analysis
    cobra.io
    cobra.manipulation
    cobra.topology

Module contents
---------------

.. automodule:: cobra
    :members:
    :undoc-members:
    :show-inheritance:
