cobra.core package
==================

Submodules
----------

cobra.core.ArrayBasedModel module
---------------------------------

.. automodule:: cobra.core.ArrayBasedModel
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.DictList module
--------------------------

.. automodule:: cobra.core.DictList
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Formula module
-------------------------

.. automodule:: cobra.core.Formula
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Gene module
----------------------

.. automodule:: cobra.core.Gene
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Metabolite module
----------------------------

.. automodule:: cobra.core.Metabolite
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Model module
-----------------------

.. automodule:: cobra.core.Model
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Object module
------------------------

.. automodule:: cobra.core.Object
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Reaction module
--------------------------

.. automodule:: cobra.core.Reaction
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Solution module
--------------------------

.. automodule:: cobra.core.Solution
    :members:
    :undoc-members:
    :show-inheritance:

cobra.core.Species module
-------------------------

.. automodule:: cobra.core.Species
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: cobra.core
    :members:
    :undoc-members:
    :show-inheritance:
