from __future__ import print_function
import cobra, copy, re, csv, warnings, pickle
from cobra import Model, Reaction, Metabolite

def importExchangeSets():
    # Imports metabolite sets as defined in the supplementary of Gille
    # et al, 2010.
    tabfiles = [
        "inline-supplementary-material-2_3.1.csv",
        "inline-supplementary-material-2_3.2.csv",
        "inline-supplementary-material-2_3.3.csv",
        "inline-supplementary-material-2_3.4.csv",
        "inline-supplementary-material-2_3.5.csv",
        "inline-supplementary-material-2_3.6.csv",
        "inline-supplementary-material-2_3.7.csv"
    ]
    gnames=["MIMES", "MIPES", "PIPES", "MES", "DES", "HES", "WES"]
    groups = dict.fromkeys(gnames)
    sdict=dict({"both":"=", "import":"-", "export":"+"})
    for i,f in enumerate(tabfiles):
        lns=list()        
        with open("data/in/exchsets/"+tabfiles[i], "r") as f:
            reader=csv.reader(f)
            next(reader, None)
            for line in reader:
                lns.append(sdict[line[3]]+line[1]+"("+line[2]+")")
        groups[gnames[i]]=lns
    return(groups)


def importW():
    # Imports reaction wights as defined in the supplementary of Gille
    # et al, 2010.
    W=[1 for i in range(2539)]
    with open("data/in/Hepatonet1weight.csv", "r") as f:
        reader=csv.reader(f)
        next(reader, None)
        for line in csv.reader(f):
            W[int(line[0][1:])-1]=int(line[1])
    return(W)


def importGibbs():
    # Imports reactions Gibb deltas as defined in the supplementary
    # of Gille et al, 2010.
    from math import exp, isnan
    lines=list()
    with open("data/in/Hepatonet1Reactions.csv", "r") as f:
        reader=csv.reader(f)
        next(reader, None)
        for line in csv.reader(f, delimiter="\t"):
            if(line[4]==""): lines.append(float("NaN"))
            else: lines.append(float(line[4]))            
    RT=8.314*37
    lines = [l if not(isnan(l)) else 0 for l in lines]
    Keq = [exp(-1*(l/RT)) for l in lines]
    return(Keq)

def importEnzymes():
    # Imports reactions Category (including enzyme IDs) defined in the
    # supplementary of Gille et al, 2010.
    from math import exp, isnan
    lines=list()
    with open("data/in/Hepatonet1Reactions.csv", "r") as f:
        reader=csv.reader(f)
        next(reader, None)
        for line in csv.reader(f, delimiter="\t"):
            lines.append(line[3])
    return lines


def importReactionList(groups):
    # Imports a list of test reactions derived from Gille et al, 2010.
    lines=list()
    with open("data/in/HepaTestsBase.csv", "r") as f:
        for line in csv.reader(f, delimiter="\t"):
            lines.append(line[0:5])
    lines = lines[2:]
    gnames = groups.keys()

    constrSignsAndNames = [re.sub(r"([-+=].+?( |$))", "\\1", line[2]).split() for line in lines]
    for i,e in enumerate(constrSignsAndNames):
        newl = list()
        for j,v in enumerate(e):
            if v in gnames:
                newl.extend(groups[v])
            else:
                newl.append(v)
        constrSignsAndNames[i]=newl
    return(lines, constrSignsAndNames)
    

def add50Rxns(model):
    # Adds 50 (actually 49 in the latest version) reactions not
    # present in Gille et al, 2010.
    nms = [m.name for m in model.metabolites]
    basei=len(model.reactions)+1
    with open("data/in/additional50rxns.txt", "r") as f:
        for i,line in enumerate(f):
            r=Reaction("r"+str(basei))
            basei=basei+1
            r.build_reaction_from_string(line, term_split=" + ", verbose=False)
            for m in r._metabolites.keys():
                if m.id in nms:
                    r._metabolites[model.metabolites[nms.index(m.id)]] = r._metabolites.pop(m)
                else:
                    m.name=m.id
            model.add_reaction(r)

    model.reactions[5105].lower_bound = model.reactions[5105].upper_bound = 0
    model.reactions[5106].lower_bound = model.reactions[5106].upper_bound = 0
    model.reactions[5112].lower_bound = model.reactions[5112].upper_bound = 0

    
def names2ids(model, constrSignsAndNames):
    # Converts metabolite names to IDs
    nms=[x.name for x in model.metabolites]
    ids=[x.id for x in model.metabolites]    
    constrIds = [[i[0]+ids[nms.index(i[1:])] if i[1:] in nms else i for i in j] for j in constrSignsAndNames]
    return(constrIds)


def importObjSigns():
    # Imports the signs of the objective functions extracted from Gille
    # et al, 2010.
    inout=list()
    with open("data/in/HepaPosNegObj.csv", "r") as f:
        for line in csv.reader(f, delimiter="\n"):
            inout.extend(line)
    return(inout)


def rmDups(objreactions):
    # Checks for duplicate single-metabolite reactions. If there are,
    # the one associated with the objective function (it's always the
    # last one) is held, the other one discarded.
    ms = [r._metabolites.keys()[0].id for r in objreactions]
    dups = list(set([x for x in ms if ms.count(x)>1]))
    for dup in dups:
        d = [i for i,j in enumerate(ms) if j in dup]
        warnings.warn("Removing duplicate reaction")
        objreactions[d[0]] = objreactions[d[-1]]
        objreactions.pop(d[-1])
        
            
def buildReactionSet(model, lines, i, constrIds, constrSignsAndNames):
    # Build a set of test reactions as obtained with
    # importReactionList
    nms=[x.name for x in model.metabolites]
    ids=[x.id for x in model.metabolites]
    inout = importObjSigns()
    line = lines[i]
    reactions = list()

    for n,e in enumerate(constrIds[i]):
        reaction=Reaction(line[0]+"_"+e)
        reaction.lower_bound = 0
        reaction.upper_bound = 1000
        if not(e[1:] in nms):
            met = Metabolite(name=e[1:], id=e[1:])
            model.add_metabolites(met)
        else:
            met = model.metabolites.get_by_id(e[1:])
        if constrSignsAndNames[i][n][0] == "-":
            reaction.add_metabolites({met: 1})
        elif constrSignsAndNames[i][n][0] == "+":
            reaction.add_metabolites({met: -1})
        else:
            reaction.lower_bound = -1000
            reaction.upper_bound = 1000
            reaction.add_metabolites({met: -1})
        reactions.append(reaction)

    reaction = Reaction(line[0]+"_"+line[1])
    if not(line[1] in nms):
        met = Metabolite(name=line[1], id=line[1])
        model.add_metabolites(met)
    else:
        met = model.metabolites.get_by_id(ids[nms.index(line[1])])
    if(inout[i] == '1'):
        reaction.add_metabolites({met : 1})
    else:
        reaction.add_metabolites({met : -1})
    reaction.lower_bound = reaction.upper_bound = 500
    reactions.append(reaction)
        
    return(reactions)


def addReverseRxns(model):
    # For every reaction in Hepatonet1, adds the inverse reaction. It
    # will be weighted differently.
    newr = list()
    reactions_ = copy.deepcopy(model.reactions)
    basei = len(model.reactions)+1
    for i,r_ in enumerate(reactions_):
        r_.id = "r"+str(basei)
        r_.name = r_.id
        basei=basei+1
        for m in r_._metabolites.keys():
            r_._metabolites[m]=-r_._metabolites[m]
        r_.upper_bound=1000
        r_.lower_bound=0
        model.reactions[i].upper_bound=1000
        model.reactions[i].lower_bound=0
        newr.append(r_)
    model.add_reactions(newr)

def buildCoefficients(model):
    # computes coefficients of the objective function combining Gibbs
    # energy and reaction weights. Input and output reactions
    # coefficients are set to 0
    W = importW()
    K = importGibbs()
    c = W
    c.extend([x[0]*x[1] for x in zip(K,W)])
    c.extend([1]*(len(model.reactions)-len(c)))
    nmets = [i for i,r in enumerate(model.reactions) if len(r._metabolites)<2]
    for i in nmets: c[i]=0
    return c
    
    
def buildModel():
    # Imports Hepatonet1 model and other initial data
    groups = importExchangeSets()
    gnames = groups.keys()
    lines, constrSignsAndNames = importReactionList(groups)
    model = cobra.io.read_sbml_model("data/in/msb201062-s5.xml", skip_boundary=False)
    return model, lines, constrSignsAndNames

